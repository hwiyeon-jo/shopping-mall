/* =========================================================
   complete.js — complete.html 전용 스크립트
   localStorage에 저장된 마지막 주문 정보를 화면에 보여줍니다.
   ========================================================= */

const order = getLastOrder();
const root = document.querySelector("[data-complete-root]");

if (!order) {
  root.innerHTML = `
    <div class="complete-mark">🤔</div>
    <h2>주문 내역이 없어요</h2>
    <p class="sub">아직 결제를 완료한 주문이 없어요.</p>
    <a href="index.html" class="btn btn-primary">쇼핑하러 가기</a>
  `;
} else {
  const itemsHtml = order.items
    .map(
      (item) => `
        <div class="row">
          <span>${item.name} (${item.size}mm / ${item.color}) x${item.qty}</span>
          <span>${formatPrice(item.price * item.qty)}</span>
        </div>`
    )
    .join("");

  root.innerHTML = `
    <div class="complete-mark">✅</div>
    <h2>주문이 완료됐어요!</h2>
    <p class="sub">SOLE을 이용해주셔서 감사해요.</p>
    <div class="order-card">
      <div class="row uid"><span>주문번호</span><span>${order.merchantUid}</span></div>
      <hr style="border:none;border-top:1px dashed var(--line);margin:10px 0" />
      ${itemsHtml}
      <hr style="border:none;border-top:1px solid var(--line);margin:10px 0" />
      <div class="row" style="font-weight:700;font-family:var(--font-mono)">
        <span>총 결제금액</span><span>${formatPrice(order.totalAmount)}</span>
      </div>
    </div>
    <a href="index.html" class="btn btn-primary">쇼핑 계속하기</a>
  `;
}
