/* =========================================================
   cart.js — cart.html 전용 스크립트
   localStorage에 담긴 장바구니를 화면에 그리고,
   수량 변경 / 삭제 / 합계 계산 / 주문하기 이동을 처리합니다.
   ========================================================= */

const FREE_SHIP_LINE = 70000; // 이 금액 이상이면 무료배송
const SHIP_FEE = 3000;

renderCart();

function renderCart() {
  const cart = getCart();
  const root = document.querySelector("[data-cart-root]");

  if (cart.length === 0) {
    root.innerHTML = `
      <div class="empty-state">
        <div class="emoji">🛒</div>
        <p>장바구니가 비어있어요.</p>
        <a href="index.html" class="btn btn-primary" style="margin-top:16px">쇼핑하러 가기</a>
      </div>
    `;
    return;
  }

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const shipping = subtotal >= FREE_SHIP_LINE ? 0 : SHIP_FEE;
  const total = subtotal + shipping;

  root.innerHTML = `
    <div class="cart-wrap">
      <div>
        ${cart.map((item, i) => cartItemTemplate(item, i)).join("")}
      </div>
      <aside class="summary-box">
        <div class="summary-row"><span>상품금액</span><span>${formatPrice(subtotal)}</span></div>
        <div class="summary-row"><span>배송비</span><span>${shipping === 0 ? "무료" : formatPrice(shipping)}</span></div>
        <div class="summary-row total"><span>총 결제금액</span><span>${formatPrice(total)}</span></div>
        <button class="btn btn-primary btn-block" data-checkout-btn style="margin-top:18px">주문하기</button>
      </aside>
    </div>
  `;

  document.querySelector("[data-checkout-btn]").addEventListener("click", () => {
    window.location.href = "checkout.html";
  });
}

function cartItemTemplate(item, index) {
  const gradient = `linear-gradient(135deg, ${item.colorway[0]}, ${item.colorway[1]})`;
  return `
    <div class="cart-item">
      <div class="thumb" style="background:${gradient}">👟</div>
      <div>
        <div class="name">${item.name}</div>
        <div class="opt">${item.brand} · ${item.size}mm · ${item.color}</div>
        <div class="qty-stepper" style="margin-top:8px">
          <button type="button" data-qty-minus="${index}">−</button>
          <span>${item.qty}</span>
          <button type="button" data-qty-plus="${index}">+</button>
        </div>
      </div>
      <div class="price">${formatPrice(item.price * item.qty)}</div>
      <button class="remove-btn" data-remove="${index}" aria-label="삭제">✕</button>
    </div>
  `;
}

// 이벤트 위임: 수량 변경 / 삭제
document.querySelector("[data-cart-root]").addEventListener("click", (e) => {
  const plusBtn = e.target.closest("[data-qty-plus]");
  const minusBtn = e.target.closest("[data-qty-minus]");
  const removeBtn = e.target.closest("[data-remove]");

  if (plusBtn) {
    const idx = Number(plusBtn.dataset.qtyPlus);
    const cart = getCart();
    updateCartQty(idx, cart[idx].qty + 1);
    renderCart();
  }
  if (minusBtn) {
    const idx = Number(minusBtn.dataset.qtyMinus);
    const cart = getCart();
    updateCartQty(idx, cart[idx].qty - 1);
    renderCart();
  }
  if (removeBtn) {
    const idx = Number(removeBtn.dataset.remove);
    Swal.fire({
      icon: "warning",
      title: "상품을 삭제할까요?",
      text: "장바구니에서 해당 상품이 사라져요.",
      showCancelButton: true,
      confirmButtonText: "삭제하기",
      cancelButtonText: "취소",
      customClass: { popup: "sole-popup", confirmButton: "sole-confirm", cancelButton: "sole-cancel" },
      buttonsStyling: false,
    }).then((result) => {
      if (result.isConfirmed) {
        removeCartItem(idx);
        renderCart();
      }
    });
  }
});
