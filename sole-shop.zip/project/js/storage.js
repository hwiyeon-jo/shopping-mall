/* =========================================================
   storage.js
   localStorage를 이용한 장바구니(cart) 저장/조회 공통 함수
   - 모든 페이지(index, product, cart, checkout)에서 공유해서 사용
   ========================================================= */

const CART_KEY = "sole_cart";
const ORDER_KEY = "sole_last_order";

// 장바구니 전체 목록 가져오기 (없으면 빈 배열)
function getCart() {
  const raw = localStorage.getItem(CART_KEY);
  return raw ? JSON.parse(raw) : [];
}

// 장바구니 통째로 저장
function saveCart(cartList) {
  localStorage.setItem(CART_KEY, JSON.stringify(cartList));
  updateCartBadge();
}

// 장바구니에 상품 추가 (같은 상품 + 같은 사이즈/색상이면 수량만 증가)
function addToCart(item) {
  const cart = getCart();
  const found = cart.find(
    (c) => c.productId === item.productId && c.size === item.size && c.color === item.color
  );
  if (found) {
    found.qty += item.qty;
  } else {
    cart.push(item);
  }
  saveCart(cart);
}

// 장바구니 특정 항목 삭제 (index 기준)
function removeCartItem(index) {
  const cart = getCart();
  cart.splice(index, 1);
  saveCart(cart);
}

// 장바구니 특정 항목 수량 변경
function updateCartQty(index, qty) {
  const cart = getCart();
  if (!cart[index]) return;
  cart[index].qty = Math.max(1, qty);
  saveCart(cart);
}

// 장바구니 비우기 (결제 완료 후 호출)
function clearCart() {
  localStorage.removeItem(CART_KEY);
  updateCartBadge();
}

// 장바구니에 담긴 총 수량 (헤더 뱃지용)
function getCartCount() {
  return getCart().reduce((sum, item) => sum + item.qty, 0);
}

// 헤더의 장바구니 뱃지 숫자를 최신 상태로 갱신
function updateCartBadge() {
  const badge = document.querySelector("[data-cart-badge]");
  if (!badge) return;
  const count = getCartCount();
  badge.textContent = count;
  badge.style.display = count > 0 ? "flex" : "none";
}

// 마지막 주문 정보 저장 / 조회 (주문완료 페이지에서 사용)
function saveLastOrder(order) {
  localStorage.setItem(ORDER_KEY, JSON.stringify(order));
}
function getLastOrder() {
  const raw = localStorage.getItem(ORDER_KEY);
  return raw ? JSON.parse(raw) : null;
}

document.addEventListener("DOMContentLoaded", updateCartBadge);
