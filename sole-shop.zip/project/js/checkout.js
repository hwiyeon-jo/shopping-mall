/* =========================================================
   checkout.js — checkout.html 전용 스크립트
   1) 장바구니 내용을 요약해서 보여주고
   2) PortOne(아임포트) SDK로 결제 요청
   3) 결제 성공 시 주문 내역 저장 + 장바구니 비우기 + 완료페이지 이동
   (실습 편의를 위해 주문자 정보 / 배송지 입력 단계는 생략했습니다)
   ========================================================= */

// 결제 테스트용 가맹점 식별코드입니다.
// 실제 서비스에서는 PortOne 관리자콘솔에서 발급받은 본인의 식별코드로 바꿔야 해요.
const IMP_MERCHANT_CODE = "imp00000000";

const cart = getCart();

// 장바구니가 비어있으면 주문할 수 없으므로 되돌려보내기
if (cart.length === 0) {
  Swal.fire({
    icon: "warning",
    title: "장바구니가 비어있어요",
    text: "상품을 먼저 담아주세요.",
    customClass: { popup: "sole-popup", confirmButton: "sole-confirm" },
    buttonsStyling: false,
  }).then(() => (window.location.href = "cart.html"));
}

const subtotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
const shipping = subtotal >= 70000 ? 0 : 3000;
const totalAmount = subtotal + shipping;

// 주문 상품 요약 렌더링
document.querySelector("[data-order-items]").innerHTML = cart
  .map(
    (item) => `
      <div class="checkout-order-item">
        <span>${item.name} (${item.size}mm) x${item.qty}</span>
        <span>${formatPrice(item.price * item.qty)}</span>
      </div>`
  )
  .join("");

document.querySelector("[data-order-total]").innerHTML =
  `<span>총 결제금액</span><span>${formatPrice(totalAmount)}</span>`;

// 결제하기 버튼 -> PortOne(아임포트) 결제창 호출
document.querySelector("#pay-btn").addEventListener("click", () => {
  const agree = document.querySelector("#agree-check").checked;
  if (!agree) {
    Swal.fire({
      icon: "warning",
      title: "결제 동의가 필요해요",
      text: "체크박스에 동의해주세요.",
      customClass: { popup: "sole-popup", confirmButton: "sole-confirm" },
      buttonsStyling: false,
    });
    return;
  }

  const IMP = window.IMP;
  IMP.init(IMP_MERCHANT_CODE);

  const merchantUid = "sole_" + Date.now();
  const orderName =
    cart.length > 1 ? `${cart[0].name} 외 ${cart.length - 1}건` : cart[0].name;

  IMP.request_pay(
    {
      pg: "html5_inicis",
      pay_method: "card",
      merchant_uid: merchantUid,
      name: orderName,
      amount: totalAmount,
      buyer_name: "SOLE 고객",
    },
    function (rsp) {
      if (rsp.success) {
        // 결제 성공 -> 주문 내역 저장 + 장바구니 비우기
        saveLastOrder({
          merchantUid: merchantUid,
          items: cart,
          totalAmount: totalAmount,
          paidAt: new Date().toISOString(),
        });
        clearCart();

        Swal.fire({
          icon: "success",
          title: "결제가 완료됐어요!",
          text: "주문 완료 페이지로 이동할게요.",
          customClass: { popup: "sole-popup", confirmButton: "sole-confirm" },
          buttonsStyling: false,
        }).then(() => {
          window.location.href = "complete.html";
        });
      } else {
        Swal.fire({
          icon: "error",
          title: "결제에 실패했어요",
          text: rsp.error_msg || "잠시 후 다시 시도해주세요.",
          customClass: { popup: "sole-popup", confirmButton: "sole-confirm" },
          buttonsStyling: false,
        });
      }
    }
  );
});
