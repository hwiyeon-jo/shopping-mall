/* =========================================================
   product.js — product.html 전용 스크립트
   URL의 ?id= 값으로 상품을 찾아 상세 정보를 그려주고,
   사이즈/색상/수량을 선택해 장바구니에 담는 기능을 담당합니다.
   ========================================================= */

const params = new URLSearchParams(window.location.search);
const productId = params.get("id");

let product = null;
let selectedSize = null;
let selectedColor = null;
let qty = 1;

fetchProductById(productId).then((p) => {
  if (!p) {
    Swal.fire({
      icon: "error",
      title: "상품을 찾을 수 없어요",
      text: "목록에서 다시 선택해주세요.",
      customClass: { popup: "sole-popup", confirmButton: "sole-confirm" },
      buttonsStyling: false,
    }).then(() => (window.location.href = "index.html"));
    return;
  }
  product = p;
  renderProduct();
});

function renderProduct() {
  document.querySelector("[data-cat]").textContent = product.category;
  document.querySelector("[data-name]").textContent = product.name;
  document.querySelector("[data-brand]").textContent = product.brand;
  document.querySelector("[data-name-title]").textContent = product.name;
  document.querySelector("[data-desc]").textContent = product.description;

  const visual = document.querySelector("[data-visual]");
  visual.style.background = `linear-gradient(135deg, ${product.colorway[0]}, ${product.colorway[1]})`;

  const priceRow = document.querySelector("[data-price-row]");
  priceRow.innerHTML = product.originalPrice
    ? `<span class="pd-price">${formatPrice(product.price)}</span><span class="pd-price-original">${formatPrice(product.originalPrice)}</span>`
    : `<span class="pd-price">${formatPrice(product.price)}</span>`;

  // 사이즈 옵션
  const sizeList = document.querySelector("[data-size-list]");
  sizeList.innerHTML = product.sizes
    .map((s) => `<button type="button" class="option-pill" data-size="${s}">${s}</button>`)
    .join("");

  // 색상 옵션
  const colorList = document.querySelector("[data-color-list]");
  colorList.innerHTML = product.colors
    .map((c) => `<button type="button" class="option-pill" data-color="${c}">${c}</button>`)
    .join("");

  document.querySelector("[data-pd-wrap]").style.display = "grid";

  if (product.stock <= 8) {
    const warn = document.querySelector("[data-stock-warn]");
    warn.style.display = "block";
    warn.textContent = `⚠ 재고 ${product.stock}개 남았어요`;
  }
}

// 사이즈/색상 선택 (이벤트 위임)
document.addEventListener("click", (e) => {
  const sizeBtn = e.target.closest("[data-size]");
  if (sizeBtn) {
    document.querySelectorAll("[data-size]").forEach((b) => b.classList.remove("selected"));
    sizeBtn.classList.add("selected");
    selectedSize = Number(sizeBtn.dataset.size);
  }
  const colorBtn = e.target.closest("[data-color]");
  if (colorBtn) {
    document.querySelectorAll("[data-color]").forEach((b) => b.classList.remove("selected"));
    colorBtn.classList.add("selected");
    selectedColor = colorBtn.dataset.color;
  }
});

// 수량 증감
document.addEventListener("click", (e) => {
  if (e.target.matches("[data-qty-plus]")) {
    qty = Math.min(qty + 1, product ? product.stock : 99);
    document.querySelector("[data-qty-value]").textContent = qty;
  }
  if (e.target.matches("[data-qty-minus]")) {
    qty = Math.max(1, qty - 1);
    document.querySelector("[data-qty-value]").textContent = qty;
  }
});

// 옵션이 다 선택됐는지 확인하는 함수
function validateOptions() {
  if (!selectedSize || !selectedColor) {
    Swal.fire({
      icon: "warning",
      title: "옵션을 선택해주세요",
      text: "사이즈와 색상을 모두 골라야 담을 수 있어요.",
      customClass: { popup: "sole-popup", confirmButton: "sole-confirm" },
      buttonsStyling: false,
    });
    return false;
  }
  return true;
}

// 현재 선택된 옵션으로 카트 아이템 객체 만들기
function buildCartItem() {
  return {
    productId: product.id,
    name: product.name,
    brand: product.brand,
    price: product.originalPrice || product.price,
    size: selectedSize,
    color: selectedColor,
    qty: qty,
    colorway: product.colorway,
  };
}

// 장바구니 담기 버튼
document.querySelector("[data-add-cart]").addEventListener("click", () => {
  if (!validateOptions()) return;
  addToCart(buildCartItem());

  Swal.fire({
    icon: "success",
    title: "장바구니에 담았어요",
    text: `${product.name} (${selectedSize}mm / ${selectedColor}) ${qty}개`,
    showCancelButton: true,
    confirmButtonText: "장바구니 보기",
    cancelButtonText: "계속 쇼핑하기",
    customClass: { popup: "sole-popup", confirmButton: "sole-confirm", cancelButton: "sole-cancel" },
    buttonsStyling: false,
  }).then((result) => {
    if (result.isConfirmed) window.location.href = "cart.html";
  });
});

// 바로 구매하기 버튼 -> 장바구니에 담고 결제 페이지로 바로 이동
document.querySelector("[data-buy-now]").addEventListener("click", () => {
  if (!validateOptions()) return;
  addToCart(buildCartItem());
  window.location.href = "checkout.html";
});
