/* =========================================================
   api.js
   axios를 사용해 상품 데이터(JSON)를 불러오는 함수
   실제 서비스라면 서버 API를 호출하겠지만,
   이 프로젝트에서는 data/products.json 파일을 "가짜 서버"처럼 사용합니다.
   ========================================================= */

// 상품 전체 목록 불러오기 -> Promise<Array>
function fetchProducts() {
  return axios.get("./data/products.json").then((res) => res.data);
}

// id로 상품 1개 찾기 -> Promise<Object|undefined>
function fetchProductById(id) {
  return fetchProducts().then((list) => list.find((p) => p.id === Number(id)));
}

// 가격을 "89,000원" 형태 문자열로 바꿔주는 함수
function formatPrice(num) {
  return num.toLocaleString("ko-KR") + "원";
}
