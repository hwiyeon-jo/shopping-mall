/* =========================================================
   main.js — index.html(홈) 전용 스크립트
   1) Swiper 배너 초기화
   2) axios로 상품 목록 가져오기
   3) 카테고리 칩 클릭 시 필터링
   ========================================================= */

// 1) Swiper 히어로 배너
new Swiper(".hero-swiper", {
  loop: true,
  autoplay: { delay: 4500, disableOnInteraction: false },
  pagination: { el: ".swiper-pagination", clickable: true },
  navigation: { nextEl: ".swiper-button-next", prevEl: ".swiper-button-prev" },
});

let allProducts = [];
let currentCategory = "전체";

// 2) 상품 데이터 불러오기
fetchProducts()
  .then((list) => {
    allProducts = list;
    document.querySelector("[data-count]").textContent = list.length;
    renderProducts();
  })
  .catch(() => {
    Swal.fire({
      icon: "error",
      title: "상품을 불러오지 못했어요",
      text: "잠시 후 다시 시도해주세요.",
      customClass: { popup: "sole-popup", confirmButton: "sole-confirm" },
      buttonsStyling: false,
    });
  });

// 카테고리별로 상품 목록을 그려주는 함수
function renderProducts() {
  const grid = document.querySelector("[data-product-grid]");
  const filtered =
    currentCategory === "전체"
      ? allProducts
      : allProducts.filter((p) => p.category === currentCategory);

  if (filtered.length === 0) {
    grid.innerHTML = `<p style="color:var(--slate)">해당 카테고리 상품이 없어요.</p>`;
    return;
  }

  grid.innerHTML = filtered.map(cardTemplate).join("");
}

// 상품 카드 1개의 HTML을 만드는 함수 (슈박스 태그 디자인)
function cardTemplate(p) {
  const gradient = `linear-gradient(135deg, ${p.colorway[0]}, ${p.colorway[1]})`;
  const badge = p.category === "세일" ? `<span class="badge sale">SALE</span>` : `<span class="badge">${p.category}</span>`;
  const priceHtml = p.originalPrice
    ? `<span class="price">${formatPrice(p.price)}</span><span class="price-original">${formatPrice(p.originalPrice)}</span>`
    : `<span class="price">${formatPrice(p.price)}</span>`;

  return `
    <a class="tag-card" href="product.html?id=${p.id}">
      <span class="hole"></span>
      ${badge}
      <div class="art" style="background:${gradient}">👟</div>
      <div class="perforation"></div>
      <div class="info">
        <div class="brand">${p.brand}</div>
        <div class="name">${p.name}</div>
        <div class="price-row">${priceHtml}</div>
      </div>
    </a>
  `;
}

// 3) 카테고리 칩 클릭 이벤트
document.querySelector("[data-chip-row]").addEventListener("click", (e) => {
  const btn = e.target.closest(".chip");
  if (!btn) return;
  document.querySelectorAll(".chip").forEach((c) => c.classList.remove("active"));
  btn.classList.add("active");
  currentCategory = btn.dataset.cat;
  renderProducts();
});
