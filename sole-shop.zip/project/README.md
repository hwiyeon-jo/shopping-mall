# SOLE — 스니커즈 쇼핑몰 (학습용 프로젝트)

인공지능소프트웨어과 3학년 실습용으로 만든 프론트엔드 쇼핑몰입니다.
순수 HTML/CSS/JS + 아래 라이브러리로 구현했습니다.

## 사용 기술
- **Swiper** : 메인 페이지 히어로 배너 (자동재생 슬라이드)
- **Axios** : `data/products.json`을 서버 API처럼 불러오기
- **LocalStorage** : 장바구니, 마지막 주문 내역 저장 (새로고침해도 안 사라짐)
- **PortOne(구 아임포트) SDK** : 결제창 호출 (`checkout.html`)
- **SweetAlert2** : 알림창/확인창 (장바구니 담기, 삭제 확인, 결제 결과 등)

## 폴더 구조
```
index.html        홈 (배너 + 상품 목록)
product.html       상품 상세
cart.html          장바구니
checkout.html      주문/결제
complete.html      주문 완료
css/style.css      전체 스타일
js/                페이지별 스크립트
data/products.json 상품 데이터 (가짜 API 역할)
vendor/            swiper, axios, sweetalert2 로컬 파일 (인터넷 없이도 동작)
```

## 실행 방법
1. 압축을 풀고 `index.html`을 더블클릭해서 열어도 되지만,
   Daum/PortOne 스크립트와 폰트는 인터넷 연결이 있어야 정상 동작해요.
2. VS Code를 쓴다면 **Live Server** 확장 프로그램으로 여는 걸 추천해요.
   (그냥 파일로 열면 일부 브라우저에서 axios가 로컬 json을 못 읽을 수 있어요)

## 꼭 알아둘 점 (선생님/학생용 메모)
- `js/checkout.js`의 `IMP_MERCHANT_CODE = "imp00000000"`는 **테스트용 코드**예요.
  실제 결제를 연동하려면 PortOne 관리자콘솔에서 발급받은 나만의 식별코드로 바꿔야 해요.
- 이 프로젝트는 실제 서버(백엔드)가 없어서, 주문 내역은 내 브라우저의 LocalStorage에만 저장돼요.
  다른 기기/브라우저에서는 보이지 않아요.
- 상품 이미지는 실제 사진 대신 CSS 그라디언트 + 이모지로 대체했어요(저작권/용량 문제 없이 자유롭게 커스텀 가능).
